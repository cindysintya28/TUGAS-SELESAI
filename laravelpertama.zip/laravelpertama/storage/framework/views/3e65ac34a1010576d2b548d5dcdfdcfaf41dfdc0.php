<?php $__env->startSection('title','cobaaaaaaa'); ?>

<?php $__env->startSection('content'); ?>
    urutan ke - <?php echo e($numbers); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelpertama\resources\views/coba.blade.php ENDPATH**/ ?>