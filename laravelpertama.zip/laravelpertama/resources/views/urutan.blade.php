@extends('layouts.app')

@section('title','urutan')

@section('content')

@foreach ($number as $number)
    <H1>Urutan Ke - {{ $number['ke']}}</H1>
    <H3>Nomor Ke - {{ $number['nomor']}}</H3>
@endforeach

@endsection